import networkx as nx
import matplotlib.pyplot as plt

# Crear un grafo de carreteras simulado
G = nx.Graph()
G.add_edge('A', 'B', weight=10)
G.add_edge('B', 'C', weight=5)
G.add_edge('C', 'D', weight=7)
G.add_edge('D', 'E', weight=3)
G.add_edge('E', 'F', weight=8)
G.add_edge('F', 'G', weight=2)

# Calcular la ruta más corta entre dos puntos
start = 'A'
end = 'G'
shortest_path = nx.shortest_path(G, start, end, weight='weight')
print("Ruta más corta:", shortest_path)

# Visualizar el grafo
nx.draw(G, with_labels=True)
plt.show()
